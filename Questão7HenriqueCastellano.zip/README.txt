EstacionamentoApp - WinForms (.NET 6)

Como abrir:
1. Baixe/extraia este projeto.
2. Abra o arquivo EstacionamentoApp.csproj no Visual Studio 2022/2023.
3. Instale o pacote NuGet: Microsoft.Data.Sqlite (se o Visual Studio não restaurar automaticamente).
4. Compile e execute.

Funcionalidades:
- Cadastrar veículos (placa, modelo, cor, proprietário)
- Cadastrar vagas (número, tipo: Carro/Moto)
- Registrar entrada: seleciona veículo e vaga livre -> marca vaga como OCUPADA
- Registrar saída: seleciona movimento ativo -> marca vaga como LIVRE e grava data de saída
- Listagens: vagas, veículos, movimentos ativos e histórico

Nota:
- O banco SQLite será criado no diretório de execução (estacionamento.db).
- A interface foi criada programaticamente sem usar o designer para facilitar inspeção do código.
